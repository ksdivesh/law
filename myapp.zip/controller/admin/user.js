exports.index = (req, res) => {
  res.json({
    status: 1,
    message: "Get users list successfully!"
  });
};
